# Testing Checklist

1. Open the live app or Product Radar page if one exists.
2. Read the product description before testing so expectations are honest.
3. Try the smallest realistic workflow.
4. Save screenshots or notes for confusing states.
5. Record blockers separately from nice-to-have polish.
