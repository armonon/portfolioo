# ScenePilot Studio Test Pack

Beat-smart video editing beta

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

Open beta: https://sattari-auto-cut.netlify.app

## What to test

Test uploads/assets, timeline plan clarity, beat/cut map usefulness, and missing export controls.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
