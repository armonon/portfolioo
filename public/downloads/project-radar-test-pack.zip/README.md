# Project Radar Directory Test Pack

Portfolio software testing directory

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

Live page: /#/product-radar

## What to test

Test whether every product is easy to find, understand, open, download, and review from a full detail page.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
