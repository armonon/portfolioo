# Context Compositor Preview Pack

Context Compositor is a creator/video editing product concept for subject-aware masking, background overlays, and faster composite building.

Status: preview/product info pack. Production installer coming soon.

Planned product direction:
- Select and track subjects through footage
- Build believable background and overlay composites
- Support masking, motion alignment, and color matching workflows
- Designed for music videos, ads, social edits, and creator content
