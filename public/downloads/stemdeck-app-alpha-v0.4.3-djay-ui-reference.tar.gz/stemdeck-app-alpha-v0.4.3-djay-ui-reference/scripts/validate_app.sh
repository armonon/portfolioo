#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
"$pkg_root/scripts/validate_stemdeck_app_bundle.sh" "$pkg_root"
plutil -p "$pkg_root/Sattari StemDeck/Sattari StemDeck.app/Contents/Info.plist" | sed -n '1,80p'
otool -L "$pkg_root/Sattari StemDeck/Sattari StemDeck.app/Contents/MacOS/Sattari StemDeck" | sed -n '1,80p'
