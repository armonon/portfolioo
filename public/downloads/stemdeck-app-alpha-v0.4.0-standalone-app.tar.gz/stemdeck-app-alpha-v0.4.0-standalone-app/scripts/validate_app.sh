#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
app="$pkg_root/Sattari StemDeck/Sattari StemDeck.app"
if [[ ! -d "$app" ]]; then
  echo "Missing Sattari StemDeck.app at $app" >&2
  exit 1
fi
codesign --verify --deep --strict --verbose=2 "$app"
file "$app/Contents/MacOS/Sattari StemDeck"
plutil -p "$app/Contents/Info.plist" | sed -n '1,80p'
