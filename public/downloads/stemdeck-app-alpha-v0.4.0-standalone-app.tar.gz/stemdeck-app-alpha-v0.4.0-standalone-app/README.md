# Sattari StemDeck app alpha v0.4.0-standalone-app

Truth label: **standalone Mac DJ app alpha**. This is an app-first StemDeck package, not a DAW plugin package and not a sale-ready release.

## Open it like an application

The app is here:

`Sattari StemDeck/Sattari StemDeck.app`

To install it for the current user:

`scripts/install_app.sh`

That copies the app to:

`~/Applications/Sattari StemDeck.app`

## What this app is

- A standalone native macOS StemDeck/DJ application built from the same JUCE engine.
- Split DJ/DAW workspace: top live mixer/stem decks, middle master/crossfader/record controls, bottom arrangement recorder lanes, right-side performance pads.
- Performance-capture direction: record the performed mix into arrangement-style lanes/metadata and master/per-deck files.
- Includes optional local Demucs setup helpers for offline stem separation experiments.

## What this app is not yet

- Not notarized yet; macOS may still show the usual alpha/Gatekeeper warning.
- Not a sale-ready release.
- Not yet a complete editable Ableton-style DAW timeline with clip dragging, comping, arrangement editing, or polished export workflow.
- Not a Windows/Linux app; this package is for Apple Silicon macOS alpha testing.

## Validation included

- Standalone app CMake/Ninja build.
- Codesign strict verification on the packaged app.
- StemDeck granular render contract.
- StemDeck time/pitch benchmark.
- StemDeck architecture contract.
