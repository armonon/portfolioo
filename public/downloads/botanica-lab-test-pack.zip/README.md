# Botanica Lab Test Pack

Botanical R&D research app

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

Live app: https://botanica-lab.netlify.app/

## What to test

Test source trails, safety wording, formula-card usefulness, and whether claims stay framed as R&D.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
