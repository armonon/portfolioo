# StemDeck sale-readiness gates

Truth label: **validation plan / not sale-ready evidence**. Passing these gates would support a sale-candidate claim; this document itself does not make one.

## Implemented in this spike

- External stem-lane loading scaffold: each deck can load pre-separated `Full mix`, `Drums`, `Bass`, `Music`, and `Vocals` audio files that share one deck playhead/transport.
- Automatable per-deck stem-lane gain parameters: `deck[A-D]Stem[Full|Drums|Bass|Music|Vocals]Gain`.
- A StemDeck-specific validation script that builds Standalone/VST3, verifies codesigning, and runs pluginval if available.
- A StemDeck-specific alpha package script that emits a truth-labeled package with install/validate helpers and this checklist.
- Lightweight full-mix key/RMS/duration analysis plus automatable manual pitch and target-key controls, rendered through granular key-lock when Preserve is enabled or resample fallback when Preserve is off.
- Host tempo sync with individual per-deck Source BPM controls, plus host-PPQ Beat Sync and per-deck Beat Grid Offset controls for beat-phase nudging.
- Live key analysis/matching toggle per deck: periodically analyzes the current playback-window key and can use that estimate for target-key pitch-shift matching, with load-time analysis as fallback.

## Explicit non-claims / current blockers

- No AI/on-device stem separation: stem lanes require pre-separated files.
- No sale-grade pitch/time engine yet: Preserve routes through the first internal granular key-lock backend, while Preserve-off still uses resample fallback and can change pitch/artifact. Real-song listening validation is still required.
- Live key analysis is lightweight chroma/Krumhansl analysis on the loaded full-mix window, not a commercial-grade polyphonic key detector yet. Validate false positives, CPU/UI stalls, and behavior during breakdowns/modulations.
- No automatic downbeat/transient detection or editable DJ beatgrid yet; Beat Sync currently follows host PPQ plus each deck's Source BPM and manual Beat Grid Offset.
- No plugin-host audio routing: a JUCE AudioPluginFormatManager discovery/load scaffold exists, but hosted VST3/AU audio/MIDI routing and UI are not productized.
- No manual DAW pass completed by this repo-only script.
- No real listening pass completed by this repo-only script.
- No installer/notarization/EULA/payment/product-page work.

## Minimum DAW smoke matrix before sale-candidate language

For each host below, test both fresh insert and restored session:

- Ableton Live: VST3 insert, load four decks, load at least two stem lanes, automate stem gains, save/reopen.
- Logic Pro: Standalone can be checked now; AU is not currently built for StemDeck, so AU support remains blocked until CMake/product config adds it.
- FL Studio: VST3 insert, transport sync on/off, play/stop host while decks are playing.
- Reaper: VST3 insert, plugin state save/reopen, sample pads, record WAV start/stop.

Record for every run:

- Host/version/macOS/CPU.
- Plugin format and path.
- Crash/hang result.
- Load time and first-play reliability.
- CPU at idle, one deck, four decks, four decks plus stems.
- Any clicks, zipper noise, pitch artifacts, sync drift, or waveform UI issues.

## Listening-pass checklist

Use known, licensed local test audio. For every deck and stem lane:

1. Load a full mix and press Play/Cue repeatedly.
2. Load matching pre-separated drums/bass/music/vocals and confirm shared start/rewind behavior.
3. Sweep stem gains from -60 dB to +12 dB through DAW automation.
4. Sweep low/mid/high EQ, filter, deck fader, crossfader, master, and limiter.
5. Toggle host sync + beat sync at 90/120/140 BPM, adjust per-deck Source BPM and Beat Grid Offset, and document sync drift / pitch artifacts honestly.
6. Enable LiveKey while playing harmonically simple and harmonically complex tracks; verify the displayed key is plausible and does not cause bad auto-match jumps.
7. Set target keys, sweep manual pitch shift, toggle Preserve on/off, and document musical quality / artifacts.
8. Record a 60-second master WAV and inspect it for clipping/silence/dropouts.
9. Save, close, reopen, and confirm file assignments restored.
10. Note the plugin-host scaffold status line; do not count it as hosted plugin processing until audio/MIDI routing is implemented.

## Packaging command

```bash
./scripts/stemdeck_manual_validation_template.sh
./scripts/package_stemdeck_alpha.sh
```

Package output defaults to:

```text
../deliverables/sattari-test-builds/stemdeck-plugin-alpha-v0.3.5-live-key/
```

Do not distribute this outside trusted internal testers until DAW/listening evidence is recorded and legal/product packaging is ready.
