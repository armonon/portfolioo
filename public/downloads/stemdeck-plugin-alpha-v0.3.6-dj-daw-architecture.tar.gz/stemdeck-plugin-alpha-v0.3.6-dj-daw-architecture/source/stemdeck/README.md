# Sattari StemDeck v0.3.5 playable-alpha groundwork

Truth label: **internal plugin build** — JUCE/CMake Standalone + VST3 build exists; the 2026-05-24 live-key build passed `./scripts/validate_stemdeck.sh` including VST3 pluginval strictness 5. Not sale-ready yet: needs AI/live stems, hosted-plugin audio/MIDI routing, manual DAW/listening validation of the beat-sync/key-lock/live-key backend, UX polish, broader file-format smoke tests, real-session testing, and product/installer work.

## Concept

Sattari StemDeck is a DJ-style four-deck remix plugin/app groundwork for producers and live DJ use. The current internal build focuses on loading tracks, mixing them with deck controls, triggering one-shot pads, and preserving enough architecture for later stem separation, sync, sampler, recording, mic, and plugin-hosting work.

## Implemented MVP

- JUCE C++ plugin/app using `AudioProcessorValueTreeState`.
- Formats: Standalone app + VST3.
- Four decks: Deck A, Deck B, Deck C, and Deck D.
- External stem lanes per deck: pre-separated Full mix, Drums, Bass, Music, and Vocals files can be loaded onto one shared deck transport/playhead. This is useful for live-stem validation with prepared stems, but it is **not** AI stem separation.
- Drag-and-drop waveform zones and file chooser loading.
- WAV/AIFF/FLAC support via JUCE basic formats; MP3 is registered when the local JUCE build exposes MP3 support.
- Waveform thumbnails per deck.
- Play toggle and cue/rewind per deck.
- Per-deck gain trim plus per-deck channel fader before the A/C vs B/D crossfader groups.
- 3-band low/mid/high EQ per deck.
- Deck filter knob per deck.
- Equal-power crossfader across deck groups A/C and B/D.
- Master gain and sample-level safety limiter.
- Host tempo snapshot display where available.
- Host tempo sync: each deck has its own editable source BPM parameter and, when Host Sync is on, playback follows host BPM by deck-specific BPM ratio.
- Beat sync/grid lock: a new global Beat Sync toggle can phase-lock decks to the host PPQ beat grid while still using each deck's individual Source BPM. Each deck also has an automatable Beat Grid Offset control for nudging alignment by beats when a track's downbeat/grid needs correction.
- Internal granular key-lock backend: when Preserve is enabled and a tempo/key/pitch move is active, deck playback uses a two-grain Hann overlap engine that advances content tempo separately from local grain pitch. It is a real pitch-preserving internal backend, but still an alpha-quality algorithm that needs listening/DAW validation before sale-candidate claims.
- Resample fallback: when Preserve is off, host sync and key/pitch controls still use the earlier playback-rate resample path.
- Key-analysis and key-match parameters: loaded full-mix audio gets a lightweight chroma/Krumhansl key estimate plus RMS/duration analysis, with manual pitch and target-key controls routed through either granular key-lock or the resample fallback depending on Preserve.
- Live key analysis/match mode: each deck has a `LiveKey` toggle. When enabled, the UI periodically analyzes an 8-second window around the deck playhead and uses that live key estimate for target-key matching and pitch-shift decisions when confidence is available, falling back to the load-time full-track key when live confidence is weak or not ready.
- Mic/input monitoring path with input bus, monitor toggle, and mic/input gain.
- 8 sample pads, each loadable and triggerable as a one-shot from the UI or keyboard keys `1`-`8` when the editor has focus.
- Automatable DAW parameters for deck play, deck source BPM, deck beat-grid offset, deck key preserve/live-key flags, deck target key, deck manual pitch shift, deck gain/fader/EQ/filter, crossfader, master, limiter ceiling, host sync/beat sync flags, mic monitor/gain, and pad gains.
- Automatable DAW parameters for per-deck stem-lane gains.
- Plugin state save/restore for APVTS params plus deck/pad file paths.
- Background thread pool for file loading; audio callback does no file IO.
- Master-output WAV recording via `MasterRecorder`: the finished master buffer is copied into a bounded queue and written by a background thread from the Record WAV button.

## Architecture classes

- `DeckPlayer`
- `WaveformDisplay`
- `MixerSection`
- `EQProcessor`
- `FilterProcessor`
- `SamplePad`
- `PadBank`
- `TransportSync`
- `MainPluginProcessor`
- `MainPluginEditor`
- `MasterRecorder`
- `PluginHostManager` JUCE `AudioPluginFormatManager` scan/load scaffold for VST3/AU discovery; no hosted audio/MIDI routing yet
- `TimePitchEngine` granular key-lock decision seam and `TrackAnalysis` groundwork
- `RoadmapAdapters` header with placeholder interfaces for stem removal, mic input, and plugin hosting

## Build

```bash
cmake -S plugins/stemdeck -B build/stemdeck -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/stemdeck --config Release --target SattariStemDeck_Standalone SattariStemDeck_VST3 -j 4
```

One-command local StemDeck gate:

```bash
./scripts/validate_stemdeck.sh
```

The gate also builds and runs `StemDeckGranularRenderContract`, a deterministic synthetic-audio contract that checks the Preserve-on granular route renders finite non-silent audio, keeps tempo-change pitch below the Preserve-off resample fallback, and raises zero-crossing rate for an octave pitch shift. This is **not** a substitute for real-song/DAW listening validation, but it protects the internal key-lock path from silent or misrouted regressions.

Manual validation report template:

```bash
./scripts/stemdeck_manual_validation_template.sh
```

Truth-labeled local alpha package:

```bash
./scripts/package_stemdeck_alpha.sh
```

## Validation

```bash
codesign --verify --deep --strict --verbose=2 "build/stemdeck/SattariStemDeck_artefacts/Release/VST3/Sattari StemDeck.vst3"
codesign --verify --deep --strict --verbose=2 "build/stemdeck/SattariStemDeck_artefacts/Release/Standalone/Sattari StemDeck.app"
/Applications/pluginval.app/Contents/MacOS/pluginval --validate-in-process --strictness-level 5 "build/stemdeck/SattariStemDeck_artefacts/Release/VST3/Sattari StemDeck.vst3"
```

Latest validation log/report: `plugins/stemdeck/logs/2026-05-23-host-scan-validation.md`.

## Current limitations

- Still not finished/sale-ready: AI/live stems, hosted-plugin processing, DAW tests, and listening pass are still missing.
- Recording write, mic input monitoring, host BPM sync, beat-grid sync, live key analysis/matching, and pluginval strictness 5 are now implemented/verified as internal-alpha features, not sale-ready features.
- No AI stem separation implementation yet; external stem lanes require prepared stem files.
- Stem-lane gain control is automatable; dedicated polished stem-mixer UX still needs product work.
- Beat-grid sync is host-PPQ/source-BPM based with per-deck beat-offset nudging; it is not yet full DJ-style transient/downbeat detection, beatgrid editing, or commercial-grade time-stretch. Preserve now enables an internal granular key-lock backend, and LiveKey can drive target-key matching from the current playback window, but these have not passed real-song listening validation or DAW matrix testing.
- JUCE plugin-host format discovery/load scaffolding exists for VST3/AU builds, but hosted audio/MIDI routing, plugin UI, and safe scan UX are not implemented yet.
- No file-browser library, MIDI pad/controller mapping, installer, or sale-ready packaging yet.
- Keyboard pad triggering requires the editor/Standalone window to have keyboard focus.
- Audio loading copies full files into memory; fine for MVP, but long DJ sets need streaming or smart caching.
- Manual DAW/listening smoke test still required before calling this a DAW-validated candidate.
