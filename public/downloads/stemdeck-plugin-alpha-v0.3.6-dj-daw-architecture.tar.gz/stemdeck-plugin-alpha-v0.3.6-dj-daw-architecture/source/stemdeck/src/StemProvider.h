#pragma once

#include <JuceHeader.h>
#include <array>
#include "DeckPlayer.h"
#include "RoadmapAdapters.h"

// Offline-first AI stem provider. It never separates in processBlock: requests run
// on a ThreadPool, results are cached on disk, and decks atomically swap buffers
// only after the generated WAV files are ready and decoded by the normal loader.
class StemProvider final : public StemRemovalAdapter
{
public:
    struct StemFile
    {
        int lane = DeckPlayer::fullMixStem;
        juce::File file;
        bool ready = false;
        juce::String status;
    };

    struct Result
    {
        juce::File sourceFile;
        juce::File cacheDirectory;
        std::array<StemFile, DeckPlayer::numStemLanes> stems;
        bool allCoreStemsReady = false;
        juce::String message;
    };

    using Callback = std::function<void(Result)>;

    StemProvider();
    ~StemProvider() override;

    juce::String getName() const override { return "StemDeck offline cached StemProvider"; }
    bool isAvailable() const override { return true; }

    void setCacheRoot (const juce::File& root);
    juce::File getCacheRoot() const;
    juce::File getCacheDirectoryForSource (const juce::File& sourceFile) const;

    void requestStemsAsync (const juce::File& sourceFile, Callback callback);
    Result inspectCache (const juce::File& sourceFile) const;

private:
    class StemJob;

    juce::File cacheRoot;
    juce::ThreadPool pool { 2 };

    static juce::String hashForFile (const juce::File& sourceFile);
    static juce::String laneCacheName (int lane);
    static bool isCoreStemLane (int lane) noexcept;
    static juce::var resultToManifest (const Result& result);
    void writeManifest (const Result& result) const;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (StemProvider)
};
