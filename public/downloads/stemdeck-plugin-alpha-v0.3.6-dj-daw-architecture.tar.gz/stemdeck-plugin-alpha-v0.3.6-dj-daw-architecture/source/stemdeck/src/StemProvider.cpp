#include "StemProvider.h"

namespace
{
juce::var objectWith (std::initializer_list<std::pair<juce::Identifier, juce::var>> properties)
{
    auto* object = new juce::DynamicObject();
    for (const auto& [key, value] : properties)
        object->setProperty (key, value);
    return juce::var (object);
}
}

class StemProvider::StemJob final : public juce::ThreadPoolJob
{
public:
    StemJob (const StemProvider& owner, juce::File source, Callback cb)
        : ThreadPoolJob ("StemDeck offline stem cache"), provider (owner), sourceFile (std::move (source)), callback (std::move (cb)) {}

    JobStatus runJob() override
    {
        auto result = provider.inspectCache (sourceFile);
        provider.writeManifest (result);

        juce::MessageManager::callAsync ([result, cb = callback]() mutable
        {
            if (cb)
                cb (std::move (result));
        });
        return jobHasFinished;
    }

private:
    const StemProvider& provider;
    juce::File sourceFile;
    Callback callback;
};

StemProvider::StemProvider()
{
    setCacheRoot (juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                    .getChildFile ("Sattari")
                    .getChildFile ("StemDeck")
                    .getChildFile ("StemCache"));
}

StemProvider::~StemProvider()
{
    pool.removeAllJobs (true, 3000);
}

void StemProvider::setCacheRoot (const juce::File& root)
{
    cacheRoot = root;
    if (! cacheRoot.exists())
        cacheRoot.createDirectory();
}

juce::File StemProvider::getCacheRoot() const
{
    return cacheRoot;
}

juce::String StemProvider::hashForFile (const juce::File& sourceFile)
{
    juce::String key = sourceFile.getFullPathName() + ":" + juce::String (sourceFile.getSize())
                     + ":" + juce::String (sourceFile.getLastModificationTime().toMilliseconds());
    return juce::String::toHexString ((int64) key.hashCode64());
}

juce::File StemProvider::getCacheDirectoryForSource (const juce::File& sourceFile) const
{
    return cacheRoot.getChildFile (hashForFile (sourceFile));
}

juce::String StemProvider::laneCacheName (int lane)
{
    return DeckPlayer::stemLaneId (lane).toLowerCase() + ".wav";
}

bool StemProvider::isCoreStemLane (int lane) noexcept
{
    return lane == DeckPlayer::drumsStem || lane == DeckPlayer::bassStem
        || lane == DeckPlayer::musicStem || lane == DeckPlayer::vocalsStem;
}

void StemProvider::requestStemsAsync (const juce::File& sourceFile, Callback callback)
{
    if (! sourceFile.existsAsFile())
        return;

    pool.addJob (new StemJob (*this, sourceFile, std::move (callback)), true);
}

StemProvider::Result StemProvider::inspectCache (const juce::File& sourceFile) const
{
    Result result;
    result.sourceFile = sourceFile;
    result.cacheDirectory = getCacheDirectoryForSource (sourceFile);
    result.cacheDirectory.createDirectory();

    for (int lane = 0; lane < DeckPlayer::numStemLanes; ++lane)
    {
        auto& stem = result.stems[(size_t) lane];
        stem.lane = lane;
        stem.file = lane == DeckPlayer::fullMixStem ? sourceFile : result.cacheDirectory.getChildFile (laneCacheName (lane));
        stem.ready = stem.file.existsAsFile();
        stem.status = stem.ready ? "ready" : (isCoreStemLane (lane) ? "missing_cached_offline_stem" : "source_full_mix");
    }

    result.allCoreStemsReady = true;
    for (int lane = 0; lane < DeckPlayer::numStemLanes; ++lane)
        if (isCoreStemLane (lane))
            result.allCoreStemsReady = result.allCoreStemsReady && result.stems[(size_t) lane].ready;

    result.message = result.allCoreStemsReady
        ? "Cached offline stems ready."
        : "Offline stem cache inspected; separation backend not run yet, so only existing cached WAVs will be loaded.";
    return result;
}

juce::var StemProvider::resultToManifest (const Result& result)
{
    juce::Array<juce::var> stemVars;
    for (const auto& stem : result.stems)
    {
        stemVars.add (objectWith ({
            { "lane", stem.lane },
            { "id", DeckPlayer::stemLaneId (stem.lane) },
            { "label", DeckPlayer::stemLaneLabel (stem.lane) },
            { "path", stem.file.getFullPathName() },
            { "ready", stem.ready },
            { "status", stem.status }
        }));
    }

    return objectWith ({
        { "schema", "SattariStemDeck.stemCache.v1" },
        { "source", result.sourceFile.getFullPathName() },
        { "cacheDirectory", result.cacheDirectory.getFullPathName() },
        { "allCoreStemsReady", result.allCoreStemsReady },
        { "message", result.message },
        { "stems", stemVars }
    });
}

void StemProvider::writeManifest (const Result& result) const
{
    auto manifest = result.cacheDirectory.getChildFile ("manifest.json");
    manifest.replaceWithText (juce::JSON::toString (resultToManifest (result), true), false, false, "\n");
}
