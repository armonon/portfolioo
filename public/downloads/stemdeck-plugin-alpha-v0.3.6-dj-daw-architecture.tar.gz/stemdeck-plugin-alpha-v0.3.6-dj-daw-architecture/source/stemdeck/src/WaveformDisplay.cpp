#include "WaveformDisplay.h"

WaveformDisplay::WaveformDisplay (juce::AudioFormatManager& manager, juce::AudioThumbnailCache& cache, juce::String deckName)
    : thumbnail (512, manager, cache), title (std::move (deckName))
{
    thumbnail.addChangeListener (this);
}

WaveformDisplay::~WaveformDisplay()
{
    thumbnail.removeChangeListener (this);
}

void WaveformDisplay::setOnFileDropped (std::function<void(const juce::File&)> callback)
{
    onFileDropped = std::move (callback);
}

void WaveformDisplay::setFile (const juce::File& file)
{
    if (file == currentFile)
        return;

    currentFile = file;
    thumbnail.clear();
    if (file.existsAsFile())
        thumbnail.setSource (new juce::FileInputSource (file));
    repaint();
}

void WaveformDisplay::paint (juce::Graphics& g)
{
    auto area = getLocalBounds().toFloat().reduced (2.0f);
    g.setColour (juce::Colour (0xff10131f));
    g.fillRoundedRectangle (area, 12.0f);
    g.setColour (juce::Colour (0xff343a4e));
    g.drawRoundedRectangle (area, 12.0f, 1.0f);

    auto textArea = getLocalBounds().reduced (12, 8);
    g.setColour (juce::Colours::white.withAlpha (0.88f));
    g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    g.drawText (title, textArea.removeFromTop (22), juce::Justification::centredLeft);

    auto wave = getLocalBounds().reduced (12, 34).toFloat();
    g.setColour (juce::Colour (0xff1b2030));
    g.fillRoundedRectangle (wave, 8.0f);

    if (thumbnail.getTotalLength() > 0.0)
    {
        g.setColour (juce::Colour (0xff67f6d2));
        thumbnail.drawChannels (g, wave.toNearestInt(), 0.0, thumbnail.getTotalLength(), 0.85f);
    }
    else
    {
        g.setColour (juce::Colours::lightgrey.withAlpha (0.55f));
        g.setFont (juce::FontOptions (13.0f));
        g.drawText ("Drop WAV / AIFF / FLAC / MP3 here", wave.toNearestInt(), juce::Justification::centred);
    }

    g.setColour (juce::Colour (0xff67f6d2).withAlpha (0.4f));
    g.drawLine (wave.getCentreX(), wave.getY(), wave.getCentreX(), wave.getBottom(), 1.0f);
}

bool WaveformDisplay::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (const auto& f : files)
    {
        const auto ext = juce::File (f).getFileExtension().toLowerCase();
        if (ext == ".wav" || ext == ".aif" || ext == ".aiff" || ext == ".flac" || ext == ".mp3")
            return true;
    }
    return false;
}

void WaveformDisplay::filesDropped (const juce::StringArray& files, int, int)
{
    if (files.isEmpty())
        return;

    const juce::File file (files[0]);
    if (onFileDropped)
        onFileDropped (file);
    setFile (file);
}

void WaveformDisplay::changeListenerCallback (juce::ChangeBroadcaster*)
{
    repaint();
}
