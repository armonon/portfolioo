# 2026-05-25 StemDeck DJ/DAW Architecture Correction

Armon requested a correction to the 4-deck DJ/DAW architecture. The app already has four decks, so this pass kept the four-deck model and added the missing architectural seams instead of adding more decks.

## Implemented

- Added `WarpEngine` as the per-deck timing contract around source BPM, beatgrid, pitch, tempo ratio, sync mode, pitch-preserving decisions, and global master BPM.
- Kept the time-stretch backend abstract via `WarpEngine::TimeStretchBackend` and `BackendDescriptor`.
- Added optional Rubber Band discovery/link flags in CMake (`SATTARI_STEMDECK_HAS_RUBBERBAND`) while preserving the existing realtime granular fallback when Rubber Band is not installed.
- Routed deck processing through `WarpEngine::Plan` so beat-sync and pitch/time decisions are centralized before the deck render path.
- Added `PerformanceRecorder` and `ArrangementBuilder` to replace the earlier capture-only arrangement logic.
- Added per-deck post-fader recorders for Deck A, Deck B, Deck C, Deck D, plus mic and master files.
- Performance event logging now reserves event capacity up front and uses a try-lock path so the audio callback does not wait on the recorder event lock.
- Arrangement JSON v2 now includes deck rendered audio, mic audio, master audio, deck lanes, clips, cue/loop automation lanes, FX/sync/tempo/pitch/EQ/filter/fader automation, and event log linkage.
- Added `HostGraph` with JUCE `AudioProcessorGraph` chains for Deck A-D, mic/vocal, and master.
- Registered plugin formats using current JUCE APIs:
  - `juce::addDefaultFormatsToManager(formatManager)` for Standalone builds.
  - `juce::addHeadlessDefaultFormatsToManager(formatManager)` for plugin/headless builds.
- Added plugin scan cache (`known-plugins.xml`) and dead-man's-pedal crash protection files under the StemDeck HostGraph app-data directory.
- Added `StemProvider` for offline-first cached stems. It inspects/writes a cache manifest in the background and only feeds stem WAVs into deck buffers once cached files exist.

## Validation

- `cmake --build build/stemdeck --target SattariStemDeck -j2` succeeded.
- `cmake --build build/stemdeck --target StemDeckGranularRenderContract -j2 && ./build/stemdeck/StemDeckGranularRenderContract` succeeded.

## Known follow-ups

- Rubber Band is not installed on this machine, so the optional high-quality backend compiled as unavailable and the realtime granular fallback remains active.
- `StemProvider` is cache/offline-first but does not yet bundle a separation model; it loads pre-generated cached WAVs and writes manifests. Next step is wiring an actual offline separator command/model into the provider.
- HostGraph supports chains/scanning/cache/crash protection, but plugin UI/chain management controls still need editor UX.
