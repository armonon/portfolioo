#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for item in "$pkg_root"/build-artefacts/*.vst3 "$pkg_root"/build-artefacts/*.app; do
  [[ -e "$item" ]] || continue
  codesign --verify --deep --strict --verbose=2 "$item"
done
if [[ -x /Applications/pluginval.app/Contents/MacOS/pluginval ]]; then
  /Applications/pluginval.app/Contents/MacOS/pluginval --validate-in-process --strictness-level 5 "$pkg_root/build-artefacts/Sattari StemDeck.vst3"
else
  echo "pluginval not found; skipping VST3 pluginval."
fi
