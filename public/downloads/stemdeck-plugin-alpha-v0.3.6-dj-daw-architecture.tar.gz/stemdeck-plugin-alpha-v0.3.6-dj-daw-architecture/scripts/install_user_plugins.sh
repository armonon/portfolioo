#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3" "$HOME/Applications"
if [[ -d "$pkg_root/build-artefacts/Sattari StemDeck.vst3" ]]; then
  ditto "$pkg_root/build-artefacts/Sattari StemDeck.vst3" "$HOME/Library/Audio/Plug-Ins/VST3/Sattari StemDeck.vst3"
fi
if [[ -d "$pkg_root/build-artefacts/Sattari StemDeck.app" ]]; then
  ditto "$pkg_root/build-artefacts/Sattari StemDeck.app" "$HOME/Applications/Sattari StemDeck.app"
fi
