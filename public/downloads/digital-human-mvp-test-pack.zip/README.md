# Digital Human MVP Test Pack

AI avatar/chat fallback demo

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

Live app: https://digital-human-mvp.onrender.com

## What to test

Test chat response reliability, avatar readiness, viseme/animation quality, and honest fallback-vs-neural positioning.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
