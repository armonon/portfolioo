# Trader Oracle Test Pack

Market research dashboard

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

Live app: https://armon-trader.netlify.app

## What to test

Test watchlist flow, ticker/news clarity, risk/invalidation language, and research-only positioning.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
