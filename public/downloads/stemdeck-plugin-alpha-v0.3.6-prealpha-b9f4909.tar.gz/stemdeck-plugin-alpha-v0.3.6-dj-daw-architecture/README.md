# Sattari StemDeck alpha v0.3.6-dj-daw-architecture

Truth label: **internal alpha validation package**. This package is not sale-ready and must not be represented as a finished product.

## Included

- VST3 and Standalone app build artefacts.
- Source snapshot for `plugins/stemdeck`.
- Local install helper: `scripts/install_user_plugins.sh`.
- Local validation helper: `scripts/validate_local.sh`.
- Optional local Demucs setup helper: `scripts/setup_stemdeck_demucs.sh`.
- DAW/listening checklist: `docs/stemdeck-sale-readiness-gates.md`.
- Manual validation report generator: `scripts/stemdeck_manual_validation_template.sh`.

## Current feature truth

- Four decks, pads, mic monitor, master recording, per-deck post-fader recording, host BPM sync, global master BPM, beat/grid sync, and limiter are present.
- External stem-lane loading exists for pre-separated Full/Drums/Bass/Music/Vocals files per deck, sharing one deck transport/playhead.
- Offline-first cached stem loading has a manifest/provider seam plus optional Demucs command integration. Demucs is not bundled in the plugin/app; run `scripts/setup_stemdeck_demucs.sh` on a local machine to create the ignored venv and write StemDeck's separator config.
- WarpEngine centralizes per-deck BPM/grid/downbeat/sync-mode/pitch/key-lock decisions and can compile against Rubber Band when available; this package still uses the realtime granular fallback on machines without Rubber Band.
- The Preserve control enables a first internal granular key-lock backend for host-sync tempo and key/pitch moves. It is verified for build/pluginval stability, but still needs real-session listening/DAW validation before any sale-candidate claim.
- LiveKey can periodically analyze the current full-mix playback window and use that estimate for target-key matching/shifting, with load-time analysis as fallback. This is alpha-quality and needs real-song listening validation.
- Beat Sync uses detected/user BPM, beat grid/downbeat correction, transient anchors, warp markers, tempo interpretation, and Strict/Groove/Anchor/Free Drift sync modes. Manual visual warp editing is still not a full editor.
- Performance recording writes master, mic, per-deck render files, event-log JSON, and arrangement JSON v2 with deck/mic/master lanes, automation lanes, and an Add New Track placeholder.
- HostGraph has a JUCE format-manager/scan/cache/load chain scaffold with empty-chain pass-through; plugin chain management/editor UX still needs product work.
- Manual DAW and real-song listening validation are still required.
