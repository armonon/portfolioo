#!/usr/bin/env bash
set -euo pipefail
pkg_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
app="$pkg_root/Sattari StemDeck/Sattari StemDeck.app"
if [[ ! -d "$app" ]]; then
  echo "Missing Sattari StemDeck.app at $app" >&2
  exit 1
fi
mkdir -p "$HOME/Applications"
ditto "$app" "$HOME/Applications/Sattari StemDeck.app"
/usr/bin/xattr -cr "$HOME/Applications/Sattari StemDeck.app" || true
/bin/chmod -R u+rwX,go+rX "$HOME/Applications/Sattari StemDeck.app"
echo "Installed Sattari StemDeck.app to $HOME/Applications"
