# Auto Pitch Test Pack

Sattari vocal tuning/audio plugin direction

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

No installer yet; preview pack only.

## What to test

Test expected vocal controls, auto-key/adapt-mode clarity, DAW packaging expectations, and listening-test requirements.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
