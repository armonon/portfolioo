# Sattari StemDeck alpha v0.3.5-live-key

Truth label: **internal alpha validation package**. This package is not sale-ready and must not be represented as a finished product.

## Included

- VST3 and Standalone app build artefacts.
- Source snapshot for `plugins/stemdeck`.
- Local install helper: `scripts/install_user_plugins.sh`.
- Local validation helper: `scripts/validate_local.sh`.
- DAW/listening checklist: `docs/stemdeck-sale-readiness-gates.md`.
- Manual validation report generator: `scripts/stemdeck_manual_validation_template.sh`.

## Current feature truth

- Four decks, pads, mic monitor, master recording, host BPM sync, host beat/grid sync, and limiter are present.
- External stem-lane loading exists for pre-separated Full/Drums/Bass/Music/Vocals files per deck, sharing one deck transport/playhead.
- No AI/on-device stem separation yet.
- The Preserve control now enables a first internal granular key-lock backend for host-sync tempo and key/pitch moves. It is verified for build/pluginval stability, but still needs real-session listening/DAW validation before any sale-candidate claim.
- LiveKey can periodically analyze the current full-mix playback window and use that estimate for target-key matching/shifting, with load-time analysis as fallback. This is alpha-quality and needs real-song listening validation.
- Beat Sync follows host PPQ with each deck's own Source BPM and Beat Grid Offset; it is not automatic transient/downbeat detection yet.
- With Preserve off, host BPM sync and key/pitch controls use the older playback-rate resample fallback.
- Plugin hosting has a JUCE format-manager/scan/load scaffold only; hosted plugin audio/MIDI routing is not implemented.
- Manual DAW and listening validation are still required.
