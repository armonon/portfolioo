#include "MainPluginProcessor.h"
#include "MainPluginEditor.h"

namespace
{
class AudioLoadJob final : public juce::ThreadPoolJob
{
public:
    AudioLoadJob (juce::File f,
                  std::function<std::shared_ptr<const DeckPlayer::LoadedAudio>(const juce::File&)> loader,
                  std::function<void(std::shared_ptr<const DeckPlayer::LoadedAudio>)> done)
        : ThreadPoolJob ("StemDeck audio load"), file (std::move (f)), load (std::move (loader)), onDone (std::move (done)) {}

    JobStatus runJob() override
    {
        auto loaded = load (file);
        juce::MessageManager::callAsync ([loaded, cb = onDone]() mutable
        {
            if (cb)
                cb (std::move (loaded));
        });
        return jobHasFinished;
    }

private:
    juce::File file;
    std::function<std::shared_ptr<const DeckPlayer::LoadedAudio>(const juce::File&)> load;
    std::function<void(std::shared_ptr<const DeckPlayer::LoadedAudio>)> onDone;
};

std::unique_ptr<juce::AudioParameterFloat> floatParam (const juce::String& id, const juce::String& name,
                                                       float min, float max, float def, const juce::String& suffix = {})
{
    juce::NormalisableRange<float> range (min, max, 0.001f);
    return std::make_unique<juce::AudioParameterFloat> (juce::ParameterID (id, 1), name, range, def,
        juce::AudioParameterFloatAttributes().withLabel (suffix));
}

std::unique_ptr<juce::AudioParameterChoice> choiceParam (const juce::String& id, const juce::String& name,
                                                         const juce::StringArray& choices, int def)
{
    return std::make_unique<juce::AudioParameterChoice> (juce::ParameterID (id, 1), name, choices, def);
}
}

MainPluginProcessor::MainPluginProcessor()
    : AudioProcessor (BusesProperties().withInput ("Mic / Input", juce::AudioChannelSet::stereo(), true)
                                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
    formatManager.registerBasicFormats();
#if JUCE_USE_MP3AUDIOFORMAT
    formatManager.registerFormat (new juce::MP3AudioFormat(), true);
#endif
    apvts.state.setProperty ("schema", "SattariStemDeck.v0.3.5", nullptr);
    for (int i = 0; i < numDecks; ++i)
    {
        liveKeyPitchClass[(size_t) i].store (-1, std::memory_order_relaxed);
        liveKeyIsMinor[(size_t) i].store (0, std::memory_order_relaxed);
        liveKeyConfidence[(size_t) i].store (0.0f, std::memory_order_relaxed);
    }
}

MainPluginProcessor::~MainPluginProcessor()
{
    loadPool.removeAllJobs (true, 1500);
}

juce::String MainPluginProcessor::deckPrefix (int deckIndex)
{
    return "deck" + juce::String::charToString ((juce_wchar) ('A' + juce::jlimit (0, numDecks - 1, deckIndex)));
}

juce::String MainPluginProcessor::deckLabel (int deckIndex)
{
    return "Deck " + juce::String::charToString ((juce_wchar) ('A' + juce::jlimit (0, numDecks - 1, deckIndex)));
}

juce::StringArray MainPluginProcessor::keyTargetChoices()
{
    juce::StringArray choices { "Off" };
    for (int pc = 0; pc < 12; ++pc)
        choices.add (TrackAnalyzer::pitchClassName (pc));
    return choices;
}

int MainPluginProcessor::keyTargetChoiceToPitchClass (int choiceIndex)
{
    return choiceIndex > 0 ? juce::jlimit (0, 11, choiceIndex - 1) : -1;
}

juce::AudioProcessorValueTreeState::ParameterLayout MainPluginProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    for (int i = 0; i < numDecks; ++i)
    {
        const auto deck = deckPrefix (i);
        const auto label = deckLabel (i);
        params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID (deck + "Play", 1), label + " Play", false));
        params.push_back (floatParam (deck + "Bpm", label + " Source BPM", 40.0f, 240.0f, 120.0f, " BPM"));
        params.push_back (floatParam (deck + "Volume", label + " Gain", -60.0f, 6.0f, 0.0f, "dB"));
        params.push_back (floatParam (deck + "Fader", label + " Channel Fader", 0.0f, 1.0f, 1.0f));
        params.push_back (floatParam (deck + "Pitch", label + " Pitch Shift", -12.0f, 12.0f, 0.0f, " st"));
        params.push_back (floatParam (deck + "BeatOffset", label + " Beat Grid Offset", -4.0f, 4.0f, 0.0f, " beats"));
        params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID (deck + "KeyLock", 1), label + " Pitch Preserve Request", false));
        params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID (deck + "LiveKey", 1), label + " Live Key Analysis", false));
        params.push_back (choiceParam (deck + "KeyTarget", label + " Match Target Key", keyTargetChoices(), 0));
        params.push_back (floatParam (deck + "Low", label + " Low", -24.0f, 12.0f, 0.0f, "dB"));
        params.push_back (floatParam (deck + "Mid", label + " Mid", -24.0f, 12.0f, 0.0f, "dB"));
        params.push_back (floatParam (deck + "High", label + " High", -24.0f, 12.0f, 0.0f, "dB"));
        params.push_back (floatParam (deck + "Filter", label + " Filter", -1.0f, 1.0f, 0.0f));

        for (int lane = 0; lane < DeckPlayer::numStemLanes; ++lane)
            params.push_back (floatParam (deck + "Stem" + DeckPlayer::stemLaneId (lane) + "Gain",
                                          label + " " + DeckPlayer::stemLaneLabel (lane) + " Stem Gain",
                                          -60.0f, 12.0f, lane == DeckPlayer::fullMixStem ? 0.0f : 0.0f, "dB"));
    }

    params.push_back (floatParam ("crossfader", "Crossfader", 0.0f, 1.0f, 0.5f));
    params.push_back (floatParam ("master", "Master", -60.0f, 6.0f, 0.0f, "dB"));
    params.push_back (floatParam ("limiterCeiling", "Limiter Ceiling", -12.0f, -0.1f, -1.0f, "dB"));
    params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID ("hostSync", 1), "Host Tempo Sync", true));
    params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID ("beatSync", 1), "Host Beat/Grid Sync", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID ("micMonitor", 1), "Mic/Input Monitor", false));
    params.push_back (floatParam ("micGain", "Mic/Input Gain", -60.0f, 6.0f, -12.0f, "dB"));

    for (int i = 0; i < PadBank::numPads; ++i)
        params.push_back (floatParam ("pad" + juce::String (i + 1) + "Gain", "Pad " + juce::String (i + 1) + " Gain", -60.0f, 6.0f, 0.0f, "dB"));

    return { params.begin(), params.end() };
}

void MainPluginProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    limiterEnvelope = 1.0f;
    for (auto& deck : decks)
        deck.prepare (sampleRate, samplesPerBlock, getTotalNumOutputChannels());
    padBank.prepare (sampleRate);
    masterRecorder.prepare (sampleRate, getTotalNumOutputChannels());
}

bool MainPluginProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& out = layouts.getMainOutputChannelSet();
    const auto& in = layouts.getMainInputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;

    return in == juce::AudioChannelSet::disabled()
        || in == juce::AudioChannelSet::mono()
        || in == juce::AudioChannelSet::stereo();
}

juce::AudioProcessorEditor* MainPluginProcessor::createEditor()
{
    return new MainPluginEditor (*this);
}

float MainPluginProcessor::getFloatParam (const juce::String& id) const
{
    if (auto* value = apvts.getRawParameterValue (id))
        return value->load();
    return 0.0f;
}

bool MainPluginProcessor::getBoolParam (const juce::String& id) const
{
    if (auto* value = apvts.getRawParameterValue (id))
        return value->load() > 0.5f;
    return false;
}

void MainPluginProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ignoreUnused (midi);
    juce::ScopedNoDenormals noDenormals;
    juce::AudioBuffer<float> micInput;
    if (getBoolParam ("micMonitor") && getTotalNumInputChannels() > 0)
        micInput.makeCopyOf (buffer, true);

    buffer.clear();

    const auto syncSnapshot = sync.update (getPlayHead());

    const float crossfader = getFloatParam ("crossfader");
    const float leftBusGain = std::cos (crossfader * juce::MathConstants<float>::halfPi);
    const float rightBusGain = std::sin (crossfader * juce::MathConstants<float>::halfPi);

    for (int i = 0; i < numDecks; ++i)
    {
        const auto deck = deckPrefix (i);
        const float deckMixGain = (i % 2 == 0) ? leftBusGain : rightBusGain;
        const float sourceBpm = juce::jlimit (40.0f, 240.0f, getFloatParam (deck + "Bpm"));
        const bool hostTempoSync = getBoolParam ("hostSync") && syncSnapshot.bpm > 1.0;
        const bool hostBeatSync = hostTempoSync && getBoolParam ("beatSync") && syncSnapshot.hostPlaying;
        const float playbackRate = hostTempoSync
                                 ? juce::jlimit (0.25f, 4.0f, (float) syncSnapshot.bpm / sourceBpm)
                                 : 1.0f;

        auto analysis = getBoolParam (deck + "LiveKey") ? getDeckLiveAnalysisFromAtomics (i) : getDeckAnalysis (i);
        if (! analysis.hasKey())
            analysis = getDeckAnalysis (i);
        const int targetKey = keyTargetChoiceToPitchClass ((int) std::round (getFloatParam (deck + "KeyTarget")));
        const float matchShift = analysis.hasKey() && targetKey >= 0
                               ? (float) TrackAnalyzer::nearestSemitoneDelta (analysis.keyPitchClass, targetKey)
                               : 0.0f;
        const TimePitchDecision timePitch = TimePitchEngine::decide ({ playbackRate,
                                                                       getFloatParam (deck + "Pitch") + matchShift,
                                                                       getBoolParam (deck + "KeyLock") });

        std::array<float, DeckPlayer::numStemLanes> stemGains {};
        for (int lane = 0; lane < DeckPlayer::numStemLanes; ++lane)
            stemGains[(size_t) lane] = getFloatParam (deck + "Stem" + DeckPlayer::stemLaneId (lane) + "Gain");

        decks[(size_t) i].process (buffer, 0, buffer.getNumSamples(), getBoolParam (deck + "Play"), getFloatParam (deck + "Volume"),
                                   getFloatParam (deck + "Fader"),
                                   getFloatParam (deck + "Low"), getFloatParam (deck + "Mid"), getFloatParam (deck + "High"),
                                   getFloatParam (deck + "Filter"), deckMixGain, timePitch, stemGains,
                                   hostBeatSync, syncSnapshot.ppqPosition, sourceBpm, getFloatParam (deck + "BeatOffset"));
    }

    if (micInput.getNumSamples() == buffer.getNumSamples())
    {
        const float micGain = juce::Decibels::decibelsToGain (getFloatParam ("micGain"));
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            buffer.addFrom (ch, 0, micInput, juce::jmin (ch, micInput.getNumChannels() - 1), 0, buffer.getNumSamples(), micGain);
    }

    std::array<float, PadBank::numPads> padGains {};
    for (int i = 0; i < PadBank::numPads; ++i)
        padGains[(size_t) i] = getFloatParam ("pad" + juce::String (i + 1) + "Gain");
    padBank.process (buffer, 0, buffer.getNumSamples(), padGains);

    buffer.applyGain (juce::Decibels::decibelsToGain (getFloatParam ("master")));
    applyLimiter (buffer, getFloatParam ("limiterCeiling"));
    masterRecorder.captureBlock (buffer);
}

void MainPluginProcessor::applyLimiter (juce::AudioBuffer<float>& buffer, float ceilingDb)
{
    const float ceiling = juce::Decibels::decibelsToGain (ceilingDb);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        float peak = 0.0f;
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            peak = juce::jmax (peak, std::abs (buffer.getSample (ch, i)));

        const float targetGain = peak > ceiling ? ceiling / (peak + 1.0e-9f) : 1.0f;
        limiterEnvelope = targetGain < limiterEnvelope ? targetGain : limiterEnvelope + 0.002f * (1.0f - limiterEnvelope);

        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
            buffer.setSample (ch, i, juce::jlimit (-0.995f, 0.995f, buffer.getSample (ch, i) * limiterEnvelope));
    }
}

juce::String MainPluginProcessor::deckPathProperty (int deckIndex)
{
    return deckPrefix (deckIndex) + "File";
}

juce::String MainPluginProcessor::deckStemPathProperty (int deckIndex, int stemLaneIndex)
{
    if (stemLaneIndex == DeckPlayer::fullMixStem)
        return deckPathProperty (deckIndex);

    return deckPrefix (deckIndex) + "Stem" + DeckPlayer::stemLaneId (stemLaneIndex) + "File";
}

juce::String MainPluginProcessor::padPathProperty (int padIndex)
{
    return "pad" + juce::String (padIndex + 1) + "File";
}

void MainPluginProcessor::setStatePathProperty (const juce::Identifier& property, const juce::String& path)
{
    apvts.state.setProperty (property, path, nullptr);
}

std::shared_ptr<const DeckPlayer::LoadedAudio> MainPluginProcessor::loadAudioFile (const juce::File& file)
{
    std::unique_ptr<juce::AudioFormatReader> reader (formatManager.createReaderFor (file));
    if (! reader || reader->lengthInSamples <= 0)
        return {};

    auto loaded = std::make_shared<DeckPlayer::LoadedAudio>();
    loaded->audio.setSize ((int) juce::jmin<int64> (reader->numChannels, 2), (int) reader->lengthInSamples);
    reader->read (&loaded->audio, 0, (int) reader->lengthInSamples, 0, true, true);
    loaded->sourceSampleRate = reader->sampleRate > 0.0 ? reader->sampleRate : 44100.0;
    loaded->path = file.getFullPathName();
    loaded->displayName = file.getFileName();
    loaded->analysis = TrackAnalyzer::analyze (loaded->audio, loaded->sourceSampleRate);
    return loaded;
}

void MainPluginProcessor::loadAudioAsync (const juce::File& file, std::function<void(std::shared_ptr<const DeckPlayer::LoadedAudio>)> onLoaded)
{
    if (! file.existsAsFile())
        return;

    loadPool.addJob (new AudioLoadJob (file,
        [this] (const juce::File& f) { return loadAudioFile (f); },
        std::move (onLoaded)), true);
}

void MainPluginProcessor::loadDeckFileAsync (int deckIndex, const juce::File& file)
{
    loadDeckStemFileAsync (deckIndex, DeckPlayer::fullMixStem, file);
}

void MainPluginProcessor::loadDeckStemFileAsync (int deckIndex, int stemLaneIndex, const juce::File& file)
{
    if (! juce::isPositiveAndBelow (deckIndex, numDecks) || ! juce::isPositiveAndBelow (stemLaneIndex, DeckPlayer::numStemLanes))
        return;

    loadAudioAsync (file, [this, deckIndex, stemLaneIndex, path = file.getFullPathName()] (std::shared_ptr<const DeckPlayer::LoadedAudio> audio)
    {
        if (! audio)
            return;
        decks[(size_t) deckIndex].setStemAudio (stemLaneIndex, audio);
        if (stemLaneIndex == DeckPlayer::fullMixStem)
            decks[(size_t) deckIndex].seekStart();
        setStatePathProperty (deckStemPathProperty (deckIndex, stemLaneIndex), path);
    });
}

void MainPluginProcessor::loadPadFileAsync (int padIndex, const juce::File& file)
{
    loadAudioAsync (file, [this, padIndex, path = file.getFullPathName()] (std::shared_ptr<const DeckPlayer::LoadedAudio> audio)
    {
        if (! audio)
            return;
        padBank.setPadAudio (padIndex, audio);
        setStatePathProperty (padPathProperty (padIndex), path);
    });
}

void MainPluginProcessor::triggerPad (int padIndex)
{
    padBank.triggerPad (padIndex);
}

void MainPluginProcessor::rewindDeck (int deckIndex)
{
    if (juce::isPositiveAndBelow (deckIndex, numDecks))
        decks[(size_t) deckIndex].seekStart();
}

bool MainPluginProcessor::beginMasterRecording (const juce::File& destinationFile)
{
    return masterRecorder.beginRecording (destinationFile);
}

juce::File MainPluginProcessor::stopMasterRecording()
{
    return masterRecorder.stopRecording();
}

juce::String MainPluginProcessor::getDeckPath (int deckIndex) const
{
    return juce::isPositiveAndBelow (deckIndex, numDecks) ? decks[(size_t) deckIndex].getPath() : juce::String{};
}

juce::String MainPluginProcessor::getDeckStemPath (int deckIndex, int stemLaneIndex) const
{
    return juce::isPositiveAndBelow (deckIndex, numDecks) && juce::isPositiveAndBelow (stemLaneIndex, DeckPlayer::numStemLanes)
        ? decks[(size_t) deckIndex].getStemPath (stemLaneIndex)
        : juce::String{};
}

juce::StringArray MainPluginProcessor::getStemLaneLabels() const
{
    juce::StringArray labels;
    for (int lane = 0; lane < DeckPlayer::numStemLanes; ++lane)
        labels.add (DeckPlayer::stemLaneLabel (lane));
    return labels;
}

juce::StringArray MainPluginProcessor::getKeyTargetChoices() const
{
    return keyTargetChoices();
}

TrackAnalysis MainPluginProcessor::getDeckAnalysis (int deckIndex) const
{
    if (! juce::isPositiveAndBelow (deckIndex, numDecks))
        return {};

    if (auto audio = decks[(size_t) deckIndex].getLoadedAudio())
        return audio->analysis;

    return {};
}

TrackAnalysis MainPluginProcessor::getDeckLiveAnalysisFromAtomics (int deckIndex) const
{
    TrackAnalysis analysis;
    if (! juce::isPositiveAndBelow (deckIndex, numDecks))
        return analysis;

    analysis.keyPitchClass = liveKeyPitchClass[(size_t) deckIndex].load (std::memory_order_relaxed);
    analysis.keyIsMinor = liveKeyIsMinor[(size_t) deckIndex].load (std::memory_order_relaxed) != 0;
    analysis.keyConfidence = liveKeyConfidence[(size_t) deckIndex].load (std::memory_order_relaxed);
    return analysis;
}

TrackAnalysis MainPluginProcessor::getDeckLiveAnalysis (int deckIndex) const
{
    return getDeckLiveAnalysisFromAtomics (deckIndex);
}

TrackAnalysis MainPluginProcessor::getDeckActiveAnalysis (int deckIndex) const
{
    if (! juce::isPositiveAndBelow (deckIndex, numDecks))
        return {};

    const auto deck = deckPrefix (deckIndex);
    auto live = getDeckLiveAnalysisFromAtomics (deckIndex);
    if (getBoolParam (deck + "LiveKey") && live.hasKey())
        return live;

    return getDeckAnalysis (deckIndex);
}

void MainPluginProcessor::refreshLiveKeyAnalysis()
{
    const auto now = juce::Time::getMillisecondCounterHiRes();

    for (int i = 0; i < numDecks; ++i)
    {
        const auto deck = deckPrefix (i);
        if (! getBoolParam (deck + "LiveKey"))
            continue;

        if (now - (double) lastLiveKeyAnalysisMs[(size_t) i] < 950.0)
            continue;

        lastLiveKeyAnalysisMs[(size_t) i] = (int64_t) now;
        const auto analysis = decks[(size_t) i].analyzeFullMixAroundPlayhead (8.0);
        liveKeyPitchClass[(size_t) i].store (analysis.keyPitchClass, std::memory_order_relaxed);
        liveKeyIsMinor[(size_t) i].store (analysis.keyIsMinor ? 1 : 0, std::memory_order_relaxed);
        liveKeyConfidence[(size_t) i].store (analysis.keyConfidence, std::memory_order_relaxed);
    }
}

juce::String MainPluginProcessor::getDeckKeyInfo (int deckIndex) const
{
    if (! juce::isPositiveAndBelow (deckIndex, numDecks))
        return {};

    const auto deck = deckPrefix (deckIndex);
    const bool liveKeyEnabled = getBoolParam (deck + "LiveKey");
    const auto liveAnalysis = getDeckLiveAnalysisFromAtomics (deckIndex);
    const auto analysis = getDeckActiveAnalysis (deckIndex);
    const int targetKey = keyTargetChoiceToPitchClass ((int) std::round (getFloatParam (deck + "KeyTarget")));
    const float manualShift = getFloatParam (deck + "Pitch");

    juce::String text = analysis.hasKey()
        ? juce::String (liveKeyEnabled && liveAnalysis.hasKey() ? "Live key: " : "Key: ") + analysis.keyName() + " (" + juce::String ((int) std::round (analysis.keyConfidence * 100.0f)) + "%)"
        : "Key: unknown";

    if (analysis.hasKey() && targetKey >= 0)
    {
        const int matchShift = TrackAnalyzer::nearestSemitoneDelta (analysis.keyPitchClass, targetKey);
        text += " → " + TrackAnalyzer::pitchClassName (targetKey) + " (" + (matchShift >= 0 ? "+" : "") + juce::String (matchShift) + " st)";
    }

    if (std::abs (manualShift) > 0.01f)
        text += " + manual " + juce::String (manualShift, 1) + " st";

    if (getBoolParam (deck + "KeyLock"))
        text += " • preserve requested";

    if (liveKeyEnabled && ! liveAnalysis.hasKey())
        text += " • live listening…";

    return text;
}

juce::String MainPluginProcessor::getDeckTimePitchStatus (int deckIndex) const
{
    if (! juce::isPositiveAndBelow (deckIndex, numDecks))
        return {};

    const auto deck = deckPrefix (deckIndex);
    const auto analysis = getDeckActiveAnalysis (deckIndex);
    const int targetKey = keyTargetChoiceToPitchClass ((int) std::round (getFloatParam (deck + "KeyTarget")));
    const float matchShift = analysis.hasKey() && targetKey >= 0
                           ? (float) TrackAnalyzer::nearestSemitoneDelta (analysis.keyPitchClass, targetKey)
                           : 0.0f;

    const auto decision = TimePitchEngine::decide ({ 1.0f, getFloatParam (deck + "Pitch") + matchShift, getBoolParam (deck + "KeyLock") });
    return decision.statusLabel;
}

juce::StringArray MainPluginProcessor::getSupportedPluginHostFormats() const
{
    return pluginHost.getSupportedPluginFormats();
}

juce::String MainPluginProcessor::getPluginHostStatus() const
{
    return pluginHost.getStatusSummary();
}

juce::String MainPluginProcessor::getPadPath (int padIndex) const
{
    return padBank.getPadPath (padIndex);
}

juce::StringArray MainPluginProcessor::getSupportedAudioExtensions() const
{
    return juce::StringArray::fromTokens (formatManager.getWildcardForAllFormats(), ";", "");
}

void MainPluginProcessor::restoreFileAssignmentsFromState()
{
    for (int i = 0; i < numDecks; ++i)
    {
        const auto path = apvts.state.getProperty (deckPathProperty (i)).toString();
        if (path.isNotEmpty())
            loadDeckFileAsync (i, juce::File (path));

        for (int lane = 1; lane < DeckPlayer::numStemLanes; ++lane)
        {
            const auto stemPath = apvts.state.getProperty (deckStemPathProperty (i, lane)).toString();
            if (stemPath.isNotEmpty())
                loadDeckStemFileAsync (i, lane, juce::File (stemPath));
        }
    }

    for (int i = 0; i < PadBank::numPads; ++i)
    {
        const auto path = apvts.state.getProperty (padPathProperty (i)).toString();
        if (path.isNotEmpty())
            loadPadFileAsync (i, juce::File (path));
    }
}

void MainPluginProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void MainPluginProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml && xml->hasTagName (apvts.state.getType()))
    {
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
        restoreFileAssignmentsFromState();
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new MainPluginProcessor();
}
