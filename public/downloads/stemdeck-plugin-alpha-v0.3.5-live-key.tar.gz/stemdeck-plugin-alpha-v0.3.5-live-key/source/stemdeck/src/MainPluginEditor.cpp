#include "MainPluginEditor.h"

juce::String MainPluginEditor::deckPrefix (int deckIndex)
{
    return "deck" + juce::String::charToString ((juce_wchar) ('A' + juce::jlimit (0, MainPluginProcessor::numDecks - 1, deckIndex)));
}

juce::String MainPluginEditor::deckLabel (int deckIndex)
{
    return "Deck " + juce::String::charToString ((juce_wchar) ('A' + juce::jlimit (0, MainPluginProcessor::numDecks - 1, deckIndex)));
}

juce::String MainPluginEditor::padKeyLabel (int padIndex)
{
    return juce::String (juce::jlimit (1, PadBank::numPads, padIndex + 1));
}

int MainPluginEditor::padIndexForKeyPress (const juce::KeyPress& key)
{
    const auto c = key.getTextCharacter();
    if (c >= '1' && c <= '8')
        return (int) (c - '1');

    return -1;
}

MainPluginEditor::MainPluginEditor (MainPluginProcessor& p)
    : AudioProcessorEditor (&p),
      processorRef (p)
{
    thumbnailFormatManager.registerBasicFormats();
#if JUCE_USE_MP3AUDIOFORMAT
    thumbnailFormatManager.registerFormat (new juce::MP3AudioFormat(), true);
#endif

    setSize (1260, 880);
    setWantsKeyboardFocus (true);
    setMouseClickGrabsKeyboardFocus (true);

    title.setText ("Sattari StemDeck", juce::dontSendNotification);
    title.setFont (juce::FontOptions (30.0f, juce::Font::bold));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (title);

    subtitle.setText ("4-deck remix groundwork • external stem lanes, live key analysis/match/shift, beat sync, recording, pads", juce::dontSendNotification);
    subtitle.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
    addAndMakeVisible (subtitle);

    tempoLabel.setColour (juce::Label::textColourId, juce::Colour (0xff67f6d2));
    tempoLabel.setJustificationType (juce::Justification::centredRight);
    addAndMakeVisible (tempoLabel);

    pluginHostStatus.setColour (juce::Label::textColourId, juce::Colours::lightgrey.withAlpha (0.82f));
    pluginHostStatus.setFont (juce::FontOptions (11.0f));
    pluginHostStatus.setJustificationType (juce::Justification::centredLeft);
    pluginHostStatus.setText (processorRef.getPluginHostStatus(), juce::dontSendNotification);
    addAndMakeVisible (pluginHostStatus);

    for (int i = 0; i < MainPluginProcessor::numDecks; ++i)
    {
        auto deckName = deckLabel (i).toUpperCase();
        deckWaves[(size_t) i] = std::make_unique<WaveformDisplay> (thumbnailFormatManager, thumbnailCache, deckName);
        deckWaves[(size_t) i]->setOnFileDropped ([this, i] (const juce::File& f) { processorRef.loadDeckFileAsync (i, f); });
        addAndMakeVisible (*deckWaves[(size_t) i]);

        setupDeck (deckControls[(size_t) i], deckPrefix (i), juce::String::charToString ((juce_wchar) ('A' + i)) + " Play");
        deckControls[(size_t) i].load.onClick = [this, i] { openDeckChooser (i); };
        deckControls[(size_t) i].loadStem.onClick = [this, i]
        {
            const int selectedLane = deckControls[(size_t) i].stemLane.getSelectedId() - 1;
            openDeckStemChooser (i, selectedLane < 0 ? DeckPlayer::fullMixStem : selectedLane);
        };
        deckControls[(size_t) i].cue.onClick = [this, i] { processorRef.rewindDeck (i); };
    }

    addAndMakeVisible (mixerPanel);
    setupSlider (crossfader, false);
    setupSlider (master, true, " dB");
    setupSlider (limiter, true, " dB");
    hostSync.setButtonText ("Host sync");
    setupButton (hostSync);
    addAndMakeVisible (hostSync);
    beatSync.setButtonText ("Beat sync");
    setupButton (beatSync);
    addAndMakeVisible (beatSync);
    micMonitor.setButtonText ("Mic monitor");
    setupButton (micMonitor);
    addAndMakeVisible (micMonitor);
    setupSlider (micGain, false, " dB");
    setupButton (recordButton);
    recordButton.onClick = [this] { toggleRecording(); };
    addAndMakeVisible (recordButton);
    recordStatus.setColour (juce::Label::textColourId, juce::Colours::lightgrey);
    recordStatus.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (recordStatus);

    crossfaderAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), "crossfader", crossfader);
    masterAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), "master", master);
    limiterAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), "limiterCeiling", limiter);
    hostSyncAttachment = std::make_unique<ButtonAttachment> (processorRef.parameters(), "hostSync", hostSync);
    beatSyncAttachment = std::make_unique<ButtonAttachment> (processorRef.parameters(), "beatSync", beatSync);
    micMonitorAttachment = std::make_unique<ButtonAttachment> (processorRef.parameters(), "micMonitor", micMonitor);
    micGainAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), "micGain", micGain);

    for (int i = 0; i < PadBank::numPads; ++i)
    {
        auto& pad = pads[(size_t) i];
        pad.trigger.setButtonText ("PAD " + juce::String (i + 1) + " [" + padKeyLabel (i) + "]");
        setupButton (pad.trigger);
        setupButton (pad.load);
        setupSlider (pad.gain, false, " dB");
        pad.trigger.onClick = [this, i] { processorRef.triggerPad (i); };
        pad.load.onClick = [this, i] { openPadChooser (i); };
        pad.gainAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), "pad" + juce::String (i + 1) + "Gain", pad.gain);
        addAndMakeVisible (pad.trigger);
        addAndMakeVisible (pad.load);
        addAndMakeVisible (pad.gain);
    }

    startTimerHz (8);

    juce::MessageManager::callAsync ([safeThis = juce::Component::SafePointer<MainPluginEditor> (this)]
    {
        if (safeThis != nullptr)
            safeThis->grabKeyboardFocus();
    });
}

bool MainPluginEditor::keyPressed (const juce::KeyPress& key)
{
    const int padIndex = padIndexForKeyPress (key);
    if (juce::isPositiveAndBelow (padIndex, PadBank::numPads))
    {
        processorRef.triggerPad (padIndex);
        return true;
    }

    return false;
}

void MainPluginEditor::setupButton (juce::Button& button)
{
    button.setWantsKeyboardFocus (false);
    button.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff1a2030));
    button.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff244f49));
    button.setColour (juce::TextButton::textColourOffId, juce::Colours::white.withAlpha (0.9f));
    button.setColour (juce::TextButton::textColourOnId, juce::Colours::white);
}

void MainPluginEditor::setupSlider (juce::Slider& slider, bool rotary, const juce::String& suffix)
{
    slider.setWantsKeyboardFocus (false);
    slider.setSliderStyle (rotary ? juce::Slider::RotaryHorizontalVerticalDrag : juce::Slider::LinearHorizontal);
    slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 74, 18);
    slider.setTextValueSuffix (suffix);
    slider.setColour (juce::Slider::rotarySliderFillColourId, juce::Colour (0xff67f6d2));
    slider.setColour (juce::Slider::trackColourId, juce::Colour (0xff67f6d2));
    slider.setColour (juce::Slider::thumbColourId, juce::Colours::white);
    slider.setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
    slider.setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    addAndMakeVisible (slider);
}

void MainPluginEditor::setupComboBox (juce::ComboBox& comboBox)
{
    comboBox.setWantsKeyboardFocus (false);
    comboBox.setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff1a2030));
    comboBox.setColour (juce::ComboBox::textColourId, juce::Colours::white.withAlpha (0.9f));
    comboBox.setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff67f6d2).withAlpha (0.35f));
    comboBox.setColour (juce::ComboBox::arrowColourId, juce::Colour (0xff67f6d2));
    comboBox.setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff101522));
    comboBox.setColour (juce::PopupMenu::textColourId, juce::Colours::white);
    addAndMakeVisible (comboBox);
}

void MainPluginEditor::setupDeck (DeckControls& controls, const juce::String& prefix, const juce::String& playText)
{
    controls.play.setButtonText (playText);
    setupButton (controls.load);
    setupButton (controls.loadStem);
    setupButton (controls.play);
    setupButton (controls.cue);
    setupComboBox (controls.stemLane);
    setupComboBox (controls.keyTarget);
    const auto stemLabels = processorRef.getStemLaneLabels();
    for (int i = 0; i < stemLabels.size(); ++i)
        controls.stemLane.addItem (stemLabels[i], i + 1);
    controls.stemLane.setSelectedId (DeckPlayer::fullMixStem + 1, juce::dontSendNotification);
    const auto keyTargets = processorRef.getKeyTargetChoices();
    for (int i = 0; i < keyTargets.size(); ++i)
        controls.keyTarget.addItem (keyTargets[i], i + 1);
    controls.keyTarget.setSelectedId (1, juce::dontSendNotification);
    controls.keyLock.setButtonText ("Preserve");
    setupButton (controls.keyLock);
    controls.liveKey.setButtonText ("LiveKey");
    setupButton (controls.liveKey);
    controls.keyInfo.setColour (juce::Label::textColourId, juce::Colours::lightgrey.withAlpha (0.9f));
    controls.keyInfo.setJustificationType (juce::Justification::centredLeft);
    controls.keyInfo.setFont (juce::FontOptions (11.0f));
    addAndMakeVisible (controls.keyInfo);
    setupSlider (controls.bpm, false, " BPM");
    setupSlider (controls.beatOffset, false, " beat");
    setupSlider (controls.volume, false, " dB");
    setupSlider (controls.fader, false);
    setupSlider (controls.pitch, false, " st");
    setupSlider (controls.low, true, " dB");
    setupSlider (controls.mid, true, " dB");
    setupSlider (controls.high, true, " dB");
    setupSlider (controls.filter, true);

    addAndMakeVisible (controls.load);
    addAndMakeVisible (controls.loadStem);
    addAndMakeVisible (controls.play);
    addAndMakeVisible (controls.cue);
    addAndMakeVisible (controls.keyLock);
    addAndMakeVisible (controls.liveKey);

    controls.playAttachment = std::make_unique<ButtonAttachment> (processorRef.parameters(), prefix + "Play", controls.play);
    controls.keyLockAttachment = std::make_unique<ButtonAttachment> (processorRef.parameters(), prefix + "KeyLock", controls.keyLock);
    controls.liveKeyAttachment = std::make_unique<ButtonAttachment> (processorRef.parameters(), prefix + "LiveKey", controls.liveKey);
    controls.keyTargetAttachment = std::make_unique<ComboBoxAttachment> (processorRef.parameters(), prefix + "KeyTarget", controls.keyTarget);
    controls.bpmAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Bpm", controls.bpm);
    controls.beatOffsetAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "BeatOffset", controls.beatOffset);
    controls.volumeAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Volume", controls.volume);
    controls.faderAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Fader", controls.fader);
    controls.pitchAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Pitch", controls.pitch);
    controls.lowAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Low", controls.low);
    controls.midAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Mid", controls.mid);
    controls.highAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "High", controls.high);
    controls.filterAttachment = std::make_unique<SliderAttachment> (processorRef.parameters(), prefix + "Filter", controls.filter);
}

void MainPluginEditor::openDeckStemChooser (int deckIndex, int stemLaneIndex)
{
    if (! juce::isPositiveAndBelow (deckIndex, MainPluginProcessor::numDecks)
        || ! juce::isPositiveAndBelow (stemLaneIndex, DeckPlayer::numStemLanes))
        return;

    deckChooser.launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this, deckIndex, stemLaneIndex] (const juce::FileChooser& chooser)
        {
            const auto file = chooser.getResult();
            if (file.existsAsFile())
            {
                processorRef.loadDeckStemFileAsync (deckIndex, stemLaneIndex, file);
                if (stemLaneIndex == DeckPlayer::fullMixStem)
                    if (auto* wave = deckWaves[(size_t) deckIndex].get())
                        wave->setFile (file);
            }
        });
}

juce::String MainPluginEditor::supportedPattern() const
{
    return "*.wav;*.aif;*.aiff;*.flac;*.mp3";
}

void MainPluginEditor::openDeckChooser (int deckIndex)
{
    if (! juce::isPositiveAndBelow (deckIndex, MainPluginProcessor::numDecks))
        return;

    deckChooser.launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this, deckIndex] (const juce::FileChooser& chooser)
        {
            const auto file = chooser.getResult();
            if (file.existsAsFile())
            {
                processorRef.loadDeckFileAsync (deckIndex, file);
                if (auto* wave = deckWaves[(size_t) deckIndex].get())
                    wave->setFile (file);
            }
        });
}

void MainPluginEditor::openPadChooser (int padIndex)
{
    padChooser.launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this, padIndex] (const juce::FileChooser& chooser)
        {
            const auto file = chooser.getResult();
            if (file.existsAsFile())
                processorRef.loadPadFileAsync (padIndex, file);
        });
}

void MainPluginEditor::toggleRecording()
{
    if (processorRef.isMasterRecording())
    {
        const auto file = processorRef.stopMasterRecording();
        recordStatus.setText (file.existsAsFile() ? "Saved: " + file.getFileName() : "Recording stopped", juce::dontSendNotification);
        return;
    }

    recordChooser.launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
        [this] (const juce::FileChooser& chooser)
        {
            auto file = chooser.getResult();
            if (file.getFullPathName().isEmpty())
                return;

            if (! file.hasFileExtension ("wav"))
                file = file.withFileExtension ("wav");

            const bool started = processorRef.beginMasterRecording (file);
            recordStatus.setText (started ? "Recording: " + file.getFileName() : "Could not start recording", juce::dontSendNotification);
        });
}

void MainPluginEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff070911));
    auto bounds = getLocalBounds().toFloat().reduced (10.0f);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff12182a), bounds.getTopLeft(),
                                             juce::Colour (0xff070911), bounds.getBottomRight(), false));
    g.fillRoundedRectangle (bounds, 18.0f);

    g.setColour (juce::Colour (0xff67f6d2).withAlpha (0.7f));
    g.drawRoundedRectangle (bounds, 18.0f, 1.2f);

    g.setColour (juce::Colours::white.withAlpha (0.62f));
    g.setFont (juce::FontOptions (11.0f, juce::Font::bold));

    for (const auto& controls : deckControls)
    {
        auto drawControlLabel = [&g] (const juce::String& text, const juce::Component& component)
        {
            auto r = component.getBounds().withHeight (16).translated (0, -16);
            g.drawText (text, r, juce::Justification::centred);
        };

        drawControlLabel ("GAIN", controls.volume);
        drawControlLabel ("BPM", controls.bpm);
        drawControlLabel ("GRID", controls.beatOffset);
        drawControlLabel ("FADER", controls.fader);
        drawControlLabel ("PITCH", controls.pitch);
        drawControlLabel ("LOW", controls.low);
        drawControlLabel ("MID", controls.mid);
        drawControlLabel ("HIGH", controls.high);
        drawControlLabel ("FILTER", controls.filter);
    }

    g.setColour (juce::Colours::white.withAlpha (0.68f));
    g.drawText ("Crossfader groups: A/C  ↔  B/D", crossfader.getBounds().withHeight (16).translated (0, -18), juce::Justification::centred);
    g.drawText ("Master", master.getBounds().withHeight (16).translated (0, -18), juce::Justification::centred);
    g.drawText ("Limit", limiter.getBounds().withHeight (16).translated (0, -18), juce::Justification::centred);
    g.drawText ("Mic gain", micGain.getBounds().withHeight (16).translated (0, -18), juce::Justification::centred);
}

void MainPluginEditor::resized()
{
    auto area = getLocalBounds().reduced (24);
    auto header = area.removeFromTop (58);
    title.setBounds (header.removeFromLeft (320));
    subtitle.setBounds (header.removeFromLeft (610));
    tempoLabel.setBounds (header);
    pluginHostStatus.setBounds (area.removeFromTop (18));
    area.removeFromTop (4);

    auto decksArea = area.removeFromTop (430);
    const int deckGap = 16;
    for (int row = 0; row < 2; ++row)
    {
        auto rowArea = decksArea.removeFromTop (205);
        if (row == 0)
            decksArea.removeFromTop (20);

        for (int col = 0; col < 2; ++col)
        {
            const int deckIndex = row * 2 + col;
            auto lane = rowArea.removeFromLeft ((rowArea.getWidth() - (col == 0 ? deckGap : 0)) / (2 - col));
            if (col == 0)
                rowArea.removeFromLeft (deckGap);

            if (auto* wave = deckWaves[(size_t) deckIndex].get())
                wave->setBounds (lane.removeFromTop (112));

            lane.removeFromTop (6);
            auto buttons = lane.removeFromTop (32);
            auto& controls = deckControls[(size_t) deckIndex];
            controls.load.setBounds (buttons.removeFromLeft (48));
            buttons.removeFromLeft (4);
            controls.stemLane.setBounds (buttons.removeFromLeft (76));
            buttons.removeFromLeft (4);
            controls.loadStem.setBounds (buttons.removeFromLeft (48));
            buttons.removeFromLeft (6);
            controls.play.setBounds (buttons.removeFromLeft (74));
            buttons.removeFromLeft (6);
            controls.cue.setBounds (buttons.removeFromLeft (42));
            buttons.removeFromLeft (6);
            controls.keyTarget.setBounds (buttons.removeFromLeft (76));
            buttons.removeFromLeft (4);
            controls.keyLock.setBounds (buttons.removeFromLeft (70));
            buttons.removeFromLeft (4);
            controls.liveKey.setBounds (buttons.removeFromLeft (74));

            lane.removeFromTop (4);
            controls.keyInfo.setBounds (lane.removeFromTop (16));
            lane.removeFromTop (2);
            controls.bpm.setBounds (lane.removeFromLeft (62).reduced (3));
            controls.beatOffset.setBounds (lane.removeFromLeft (62).reduced (3));
            controls.volume.setBounds (lane.removeFromLeft (62).reduced (3));
            controls.fader.setBounds (lane.removeFromLeft (62).reduced (3));
            controls.pitch.setBounds (lane.removeFromLeft (62).reduced (3));
            controls.low.setBounds (lane.removeFromLeft (54).reduced (2));
            controls.mid.setBounds (lane.removeFromLeft (54).reduced (2));
            controls.high.setBounds (lane.removeFromLeft (54).reduced (2));
            controls.filter.setBounds (lane.removeFromLeft (54).reduced (2));
        }
    }

    auto mixer = area.removeFromTop (120).reduced (0, 6);
    mixerPanel.setBounds (mixer.removeFromLeft (150));
    auto mixControls = mixer.reduced (12, 12);
    crossfader.setBounds (mixControls.removeFromLeft (300));
    mixControls.removeFromLeft (20);
    master.setBounds (mixControls.removeFromLeft (84));
    limiter.setBounds (mixControls.removeFromLeft (84));
    hostSync.setBounds (mixControls.removeFromLeft (120).withTrimmedTop (24));
    beatSync.setBounds (mixControls.removeFromLeft (118).withTrimmedTop (24));
    micMonitor.setBounds (mixControls.removeFromLeft (130).withTrimmedTop (24));
    micGain.setBounds (mixControls.removeFromLeft (120));
    recordButton.setBounds (mixControls.removeFromLeft (120).withTrimmedTop (20).withHeight (32));
    recordStatus.setBounds (mixControls.withTrimmedTop (20).withHeight (32));

    area.removeFromTop (8);
    auto padArea = area.removeFromTop (170);
    const int padW = padArea.getWidth() / 4;
    for (int row = 0; row < 2; ++row)
    {
        auto rowArea = padArea.removeFromTop (80);
        for (int col = 0; col < 4; ++col)
        {
            const int i = row * 4 + col;
            auto cell = rowArea.removeFromLeft (padW).reduced (5);
            pads[(size_t) i].trigger.setBounds (cell.removeFromTop (30));
            pads[(size_t) i].load.setBounds (cell.removeFromLeft (52));
            pads[(size_t) i].gain.setBounds (cell);
        }
    }
}

void MainPluginEditor::timerCallback()
{
    processorRef.refreshLiveKeyAnalysis();
    auto snapshot = processorRef.getTransportSnapshot();
    tempoLabel.setText (juce::String (snapshot.bpm, 1) + " BPM • " + (snapshot.hostPlaying ? "host playing" : "host stopped"), juce::dontSendNotification);
    pluginHostStatus.setText (processorRef.getPluginHostStatus(), juce::dontSendNotification);
    recordButton.setButtonText (processorRef.isMasterRecording() ? "Stop Rec" : "Record WAV");

    for (int i = 0; i < MainPluginProcessor::numDecks; ++i)
    {
        deckControls[(size_t) i].keyInfo.setText (processorRef.getDeckKeyInfo (i) + " • " + processorRef.getDeckTimePitchStatus (i),
                                                   juce::dontSendNotification);

        const auto path = processorRef.getDeckPath (i);
        if (path != deckPaths[(size_t) i])
        {
            deckPaths[(size_t) i] = path;
            if (path.isNotEmpty())
                if (auto* wave = deckWaves[(size_t) i].get())
                    wave->setFile (juce::File (path));
        }
    }
}
