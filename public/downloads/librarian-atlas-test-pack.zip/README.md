# Librarian Atlas Test Pack

Provenance-first public-domain book atlas

Status note: this downloadable is an honest testing/preview pack. It is not a full installer unless the product page explicitly says so.

Live app: https://librarian-atlas.netlify.app

## What to test

Test book discovery, source inspection, authority links, and public-domain/readability claim clarity.

## Suggested notes to capture

- What was clear?
- What was confusing?
- What would make this easier to test?
- What is the first blocker before a real public beta or sale-ready release?
